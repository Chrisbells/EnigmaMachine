function letterIndex(letter){
    return letter.lowerCase().charCodeAt(0)-97
}