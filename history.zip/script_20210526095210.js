// resources
// https://www.cryptomuseum.com/crypto/enigma/wiring.htm#9
// https://www.cs.cornell.edu/courses/cs3110/2018sp/a1/a1.html

//wiring for enigma 1
entry="abcdefghijklmnopqrstuvwxyz".split("")
wheel1=new Rotor("ekmflgdqvzntowyhxuspaibrcj",'y','q')
wheel2=new Rotor("ajdksiruxblhwtmcqgznpyfvoe","m","e")
wheel3=new Rotor("bdfhjlcprtxvznyeiwgakmusqo","d","v")
wheel4=new Rotor("esovpzjayquirhxlnftgkdcmwb","r","j")
wheel5=new Rotor("vzbrgityupsdnhlxawmjqofeck","h","z")
reflectorA=new Reflector("ejmzalyxvbwfcrquontspikhgd")
reflectorB=new Reflector("yruhqsldpxngokmiebfzcwvjat")
reflectorC=new Reflector("fvpjiaoyedrzxwgctkuqsbnmhl")

letterIndex = (letter) => letter.charCodeAt(0)-97
letterMap = (letter,mappingArray) => mappingArray[letterIndex(letter)]
class Rotor{
    constructor(letterMap,notch,turnover){
        this.map=letterMap.split("")
        this.notch=letterIndex(notch)
        this.turnover=letterIndex(turnover)
    }
    setPosition(pos){
        this.pos=pos
    }
    input(letter){
        return this.map[(letterIndex(letter)+this.pos)%26]
    }
}
class Reflector{
    constructor(letterMap){
        this.map=letterMap.split("")
    }
    input(letter){
        return this.map[letterIndex(letter)]
    }
}
class Enigma{
    constructor(leftWheel,leftWheelPos,middleWheel,middleWheelPos,rightWheel,rightWheelPos,reflector){
        this.wheels=[rightWheel,middleWheel,leftWheel]
        leftWheel.setPosition(leftWheelPos)
        middleWheel.setPosition(middleWheelPos)
        rightWheel.setPosition(rightWheelPos)
        this.reflector=reflector
    }
    increment() {
        this.positions[0]+=1
        if(this.positions>)
    }
}