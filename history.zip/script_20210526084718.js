function letterIndex(letter){
    return "".charCodeAt(0)
}
letterIndex("d")