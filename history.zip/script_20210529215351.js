//currently 122 lines check in an hour or so
// resources
// https://www.cryptomuseum.com/crypto/enigma/wiring.htm#9
// https://www.cs.cornell.edu/courses/cs3110/2018sp/a1/a1.html
/*
TODO
enigma configuration
keyboard input
keypress anim
visualizer
input output history
ioHistory
plugboard
*/
const quertz = "QWERTZUIOASDFGHJKPYXCVBNML".split("")
const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("")
//create keyboard and lamp board

// ********** inner workings of enigma machine **********

// wire mapping and turnover positions for enigma 1 machine
const rotorConfigs = [
    ["EKMFLGDQVZNTOWYHXUSPAIBRCJ", "Q"],
    ["AJDKSIRUXBLHWTMCQGZNPYFVOE", "E"],
    ["BDFHJLCPRTXVZNYEIWGAKMUSQO", "V"],
    ["ESOVPZJAYQUIRHXLNFTGKDCMWB", "J"],
    ["VZBRGITYUPSDNHLXAWMJQOFECK", "Z"]
]
const reflectorConfigs = [
    "EJMZALYXVBWFCRQUONTSPIKHGD",
    "YRUHQSLDPXNGOKMIEBFZCWVJAT",
    "FVPJIAOYEDRZXWGCTKUQSBNMHL",
]
letterIndex = (letter) => letter.charCodeAt(0) - 65

class Rotor {
    constructor(rotorType, initPosition) {
        console.log(rotorConfigs)
        this.map = rotorConfigs[rotorType][0].split("")
        this.turnover = letterIndex(rotorConfigs[rotorType][1])
        this.position = letterIndex(initPosition)
    }
    increment() {
        this.position++
        this.position %= 26
    }
    atTurnover() {
        return this.position == this.turnover
    }
    inputFromRight(letter) {
        return this.map[(letterIndex(letter) + this.position) % 26]
    }
    inputFromLeft(letter) {
        return alphabet[Math.abs(this.map.indexOf(letter) - this.position) % 26]
    }
}
class Reflector {
    constructor(reflectorType) {
        this.map = reflectorConfigs[reflectorType].split("")
    }
    input(letter) {
        return this.map[letterIndex(letter)]
    }
}
class Enigma {
    constructor(rotors, reflector) {
        this.rotors = rotors
        this.reflector = reflector
    }
    input(letter) {
        let out = letter
        let path=[]
        //going right to left through rotors
        for (let rotor = this.rotors.length - 1; rotor >= 0; rotor--) {
            out = this.rotors[rotor].inputFromRight(out)
            path.push(out)
        }
        //reflector
        out = this.reflector.input(out)
        path.push(out)
        //going left to right through rotors
        for (let rotor = 0; rotor < this.rotors.length; rotor++) {
            out = this.rotors[rotor].inputFromLeft(out)
            path.push(out)
        }
        return {"out":out,"path":path}

    }
    increment() {
        //when a rotor is at its turnover position and increments then the next rotor over also increments
        //for the middle rotor to move the right rotor has to be at its turnover position
        let midRotorIncremented
        if (this.rotors[2].atTurnover()) {
            this.rotors[1].increment()
            midRotorIncremented = true
        }
        //for the left rotor to move the middle and right rotor have to be at their turnover position
        if (this.rotors[0].atTurnover() && midRotorIncremented) {
            this.rotors[0].increment()
        }
        this.rotors[2].increment()
    }
}

// ********** ui stuff **********

//default enigma machine using rotors I-II-III and all in first position
let enigma = new Enigma([
    //left to right
    new Rotor(0, "A"),
    new Rotor(1, "A"),
    new Rotor(2, "A")
], new Reflector(1))

let inHistory=document.querySelector("#inputHistory")
let outHistory=document.querySelector("#outputHistory")

let keyRows = document.querySelectorAll(".keyRow")
let lampRows = document.querySelectorAll(".lampRow")

let lamps = []

quertz.forEach((letter, index) => {
    if (index < 9) { row = 0 } else if (index < 17) { row = 1 } else { row = 2 }
    let key = document.createElement("button")
    let lamp = document.createElement("div")

    key.textContent = lamp.textContent = letter

    key.className = "key"
    lamp.className = "lamp"

    key.addEventListener("click", _ => { handleInput(letter) })

    keyRows[row].appendChild(key)
    lampRows[row].appendChild(lamp)

    lamps.push(lamp)
})

function handleInput(letter){
    out=enigma.input(letter)
    //showPath(out.path)
    lightLamp(out.out)
    inHistory.innerHTML+=letter
    outHistory.innerHTML+=out.out
    enigma.increment()
}
function lightLamp(letter) {
    let el = lamps[quertz.indexOf(letter)]
    el.classList.add("on")
    setTimeout(_ => el.classList.remove("on"), (500));
}

