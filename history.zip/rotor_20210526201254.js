class Rotor {
    constructor(letterMap, notch, turnover) {
        this.map = letterMap.split("")
        this.notch = letterIndex(notch)
        this.turnover = letterIndex(turnover)
    }
    setPosition(pos) {
        this.pos = pos
    }
    inputFromRight(letter) {
        return this.map[(letterIndex(letter) + this.pos) % 26]
    }
    inputFromLeft(letter) {
        return alphabet[(this.map.find(letter)+this.pos) % 26]
    }
}