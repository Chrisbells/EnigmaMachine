// resources
// https://www.cryptomuseum.com/crypto/enigma/wiring.htm#9
// https://www.cs.cornell.edu/courses/cs3110/2018sp/a1/a1.html

//wiring for enigma 1
entry="abcdefghijklmnopqrstuvwxyz".split("")
wheel1="ekmflgdqvzntowyhxuspaibrcj".split("")
wheel2="ajdksiruxblhwtmcqgznpyfvoe".split("")
wheel3="bdfhjlcprtxvznyeiwgakmusqo".split("")
wheel4="esovpzjayquirhxlnftgkdcmwb".split("")
wheel5="vzbrgityupsdnhlxawmjqofeck".split("")
reflectorA="ejmzalyxvbwfcrquontspikhgd".split("")
reflectorB="yruhqsldpxngokmiebfzcwvjat".split("")
reflectorC="fvpjiaoyedrzxwgctkuqsbnmhl".split("")

letterIndex = (letter) => letter.charCodeAt(0)-97
letterMap = (letter,mappingArray) => mappingArray[letterIndex(letter)]
class Enigma{
    constructor(leftWheel,leftWheelPos,middleWheel,middleWheelPos,rightWheel,rightWheelPos,reflector){
        this.wheels=[rightWheel.middleWheel,leftWheel]
        this.positions=[leftWheelPos,middleWheelPos,rightWheelPos]
        this.reflector=reflector
    }
    function increment() {
        this.positions[2]
    }
}