function letterIndex(letter){
    return letter.charCodeAt(0)
}