// resources
// https://www.cryptomuseum.com/crypto/enigma/wiring.htm#9
// https://www.cs.cornell.edu/courses/cs3110/2018sp/a1/a1.html

const quertz = "QWERTZUIOASDFGHJKPYXCVBNML".split("")
const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("")
const keys = document.querySelectorAll(".key")
const lamps = document.querySelectorAll(".lamp")
// wire mapping and turnover positions for enigma 1 machine
const rotorConfigs=[
    ["EKMFLGDQVZNTOWYHXUSPAIBRCJ", "Q"],
    ["AJDKSIRUXBLHWTMCQGZNPYFVOE", "E"],
    ["BDFHJLCPRTXVZNYEIWGAKMUSQO", "V"],
    ["ESOVPZJAYQUIRHXLNFTGKDCMWB", "J"],
    ["VZBRGITYUPSDNHLXAWMJQOFECK", "Z"]
] 
const reflectorConfigs=[
    "EJMZALYXVBWFCRQUONTSPIKHGD",
    "YRUHQSLDPXNGOKMIEBFZCWVJAT",
    "FVPJIAOYEDRZXWGCTKUQSBNMHL",
]
letterIndex = (letter) => letter.charCodeAt(0) - 65
class Rotor {
    constructor(rotorType,initPosition) {
        this.map = rotorConfigs[rotorType].split("")
        this.turnover = letterIndex(rotorConfigs[rotorType])
        this.position=initPosition
    }
    increment(){
        this.position++
        this.position%=26
    }
    atTurnover(){
        return this.position==this.turnover
    }
    inputFromRight(letter) {
        console.log((letterIndex(letter) + this.position) % 26)
        console.log(this.map)
        return this.map[(letterIndex(letter) + this.position) % 26]
    }
    inputFromLeft(letter) {
        return alphabet[(this.map.indexOf(letter)+this.position) % 26]
    }
}
class Reflector {
    constructor(reflectorType) {
        this.map = reflectorConfigs[reflectorType].split("")
    }
    input(letter) {
        console.log(letterIndex(letter))
        console.log(this.map+"ref")
        return this.map[letterIndex(letter)]
    }
}
class Enigma {
    constructor(rotors, reflector) {
        this.rotors = rotors
        this.reflector = reflector
    }
    input(letter) {
        let temp = letter
        console.log(temp)
        //going right to left through rotors
        for (let rotor = 0; rotor < this.rotors.length; rotor++) {
            temp = this.rotors[rotor].inputFromRight(temp)
            console.log(temp)
        }
        //reflector
        temp = this.reflector.input(temp)
        console.log(temp)
        //going left to right through rotors
        for (let rotor = this.rotors.length - 1; rotor >= 0; rotor--) {
            temp = this.rotors[rotor].inputFromLeft(temp)
            console.log(temp)
        }
        return temp
    }
    increment(){
        //when a rotor is at its turnover position and increments then the next rotor over also increments
        //for the middle rotor to move the right rotor has to be at its turnover position
        let midRotorIncremented
        if(this.rotors[0].atTurnover()) {
            this.rotors[1].increment()
            midRotorIncremented=true
        }
        //for the left rotor to move the middle and right rotor have to be at their turnover position
        if(this.rotors[1].atTurnover() && midRotorIncremented) {
            this.rotors[2].increment()
        }
        this.rotors[0].increment()
    }
}

function lightLamp(letter){
    let el = document.querySelectorAll(".lamp")[quertz.indexOf(letter)]
    el.classList.add("on")
    setTimeout(() => {
        el.classList.remove("on")
    }, (500));
}

let enigma=new Enigma([
    //left to right
    new Rotor(2,0),
    new Rotor(1,0),
    new Rotor(0,0)
],new Reflector(2))
keys.forEach(key=>{
    key.addEventListener("click",_=>{
        let output = enigma.input(key.innerHTML)
        lightLamp(output)
        enigma.increment()
    })
})
