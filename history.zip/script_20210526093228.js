// resources
// https://www.cryptomuseum.com/crypto/enigma/wiring.htm#9
// https://www.cs.cornell.edu/courses/cs3110/2018sp/a1/a1.html

//wiring for enigma 1
entry=new Rotor("abcdefghijklmnopqrstuvwxyz",static=true)
wheel1="ekmflgdqvzntowyhxuspaibrcj".split("")
wheel2="ajdksiruxblhwtmcqgznpyfvoe".split("")
wheel3="bdfhjlcprtxvznyeiwgakmusqo".split("")
wheel4="esovpzjayquirhxlnftgkdcmwb".split("")
wheel5="vzbrgityupsdnhlxawmjqofeck".split("")
reflectorA="ejmzalyxvbwfcrquontspikhgd".split("")
reflectorB="yruhqsldpxngokmiebfzcwvjat".split("")
reflectorC="fvpjiaoyedrzxwgctkuqsbnmhl".split("")

letterIndex = (letter) => letter.charCodeAt(0)-97
letterMap = (letter,mappingArray) => mappingArray[letterIndex(letter)]
class Rotor{
    constructor(letterMap,notch,turnover,static=false){
        this.map=letterMap.split("")
        if (!static){
            this.notch=notch
            this.turnover=turnover
        }
    }
}
class Enigma{
    constructor(leftWheel,leftWheelPos,middleWheel,middleWheelPos,rightWheel,rightWheelPos,reflector){
        this.wheels=[rightWheel.middleWheel,leftWheel]
        this.positions=[rightWheelPos,middleWheelPos,leftWheelPos]
        this.reflector=reflector
    }
    increment() {
        this.positions[0]+=1
        if(this.positions>)
    }
}