//currently 122 lines check in an hour or so
// resources
// https://www.cryptomuseum.com/crypto/enigma/wiring.htm#9
// https://www.cs.cornell.edu/courses/cs3110/2018sp/a1/a1.html
/*
HEY CHRIS GOOD MORNING GOOD JOB ON FINISHING THE HISTORY, SETTINGS, ANIMATIONS, AND KEYBOARD INPUT YESTERDAY
TODAY YOU JUST GOTTA DO THE FOLLOWING 
visualizer
plugboard
*/
const quertz = "QWERTZUIOASDFGHJKPYXCVBNML".split("")
const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("")

// ********** inner workings of enigma machine **********
// wire mapping and turnover positions for enigma 1 machine
const rotorConfigs = [
    ["EKMFLGDQVZNTOWYHXUSPAIBRCJ", "Q"],
    ["AJDKSIRUXBLHWTMCQGZNPYFVOE", "E"],
    ["BDFHJLCPRTXVZNYEIWGAKMUSQO", "V"],
    ["ESOVPZJAYQUIRHXLNFTGKDCMWB", "J"],
    ["VZBRGITYUPSDNHLXAWMJQOFECK", "Z"]
]
const reflectorConfigs = [
    "EJMZALYXVBWFCRQUONTSPIKHGD",
    "YRUHQSLDPXNGOKMIEBFZCWVJAT",
    "FVPJIAOYEDRZXWGCTKUQSBNMHL",
]

letterIndex = (letter) => letter.charCodeAt(0) - 65

class Rotor {
    constructor(rotorType, initPosition) {
        console.log(rotorConfigs)
        this.map = rotorConfigs[rotorType][0].split("")
        this.turnover = letterIndex(rotorConfigs[rotorType][1])
        this.position = letterIndex(initPosition)
    }
    increment() {
        this.position++
        this.position %= 26
    }
    atTurnover() {
        return this.position == this.turnover
    }
    inputFromRight(letter) {
        return this.map[(letterIndex(letter) + this.position) % 26]
    }
    inputFromLeft(letter) {
        let e=letterIndex+this.position%26
        return alphabet[this.map.indexOf(String.fromCharCode(65+e))]
    }
}
class Reflector {
    constructor(reflectorType) {
        this.map = reflectorConfigs[reflectorType].split("")
    }
    input(letter) {
        return this.map[letterIndex(letter)]
    }
}
class Enigma {
    constructor(rotors, reflector) {
        this.rotors = rotors
        this.reflector = reflector
    }
    input(letter) {
        let out = letter
        let path = []
        //going right to left through rotors
        for (let rotor = this.rotors.length - 1; rotor >= 0; rotor--) {
            out = this.rotors[rotor].inputFromRight(out)
            path.push(out)
            console.log(rotor+1)
        }
        //reflector
        out = this.reflector.input(out)
        console.log("reflector")
        path.push(out)
        //going left to right through rotors
        for (let rotor = 0; rotor < this.rotors.length; rotor++) {
            out = this.rotors[rotor].inputFromLeft(out)
            path.push(out)
            console.log(rotor+1)
        }
        console.log(path)
        return { "out": out, "path": path }

    }
    increment() {
        //when a rotor is at its turnover position and increments then the next rotor over also increments
        //for the middle rotor to move the right rotor has to be at its turnover position
        let midRotorIncremented
        if (this.rotors[2].atTurnover()) {
            this.rotors[1].increment()
            midRotorIncremented = true
        }
        //for the left rotor to move the middle and right rotor have to be at their turnover position
        if (this.rotors[0].atTurnover() && midRotorIncremented) {
            this.rotors[0].increment()
        }
        this.rotors[2].increment()
    }
}

// ********** ui stuff **********

//default enigma machine using rotors I-II-III and all in first position
let enigma = new Enigma([
    //left to right
    new Rotor(0, "A"),
    new Rotor(1, "A"),
    new Rotor(2, "A")
], new Reflector(1))

let lamps = []
let keys = []


let inHistory = document.querySelector("#inputHistory")
let outHistory = document.querySelector("#outputHistory")

let keyRows = document.querySelectorAll(".keyRow")
let lampRows = document.querySelectorAll(".lampRow")

// create buttons and lamps
quertz.forEach((letter, index) => {
    if (index < 9) { row = 0 } else if (index < 17) { row = 1 } else { row = 2 }
    let key = document.createElement("button")
    let lamp = document.createElement("div")

    key.textContent = lamp.textContent = letter

    key.className = "key"
    lamp.className = "lamp"

    key.addEventListener("click", _ => { handleInput(letter) })

    keyRows[row].appendChild(key)
    lampRows[row].appendChild(lamp)
    keys.push(key)
    lamps.push(lamp)
})

//physical keyboard support
document.querySelector("#keyboardButton").addEventListener("keypress", (e) => {
    if (/[a-z]/.test(e.key)) {
        handleInput(e.key.toUpperCase())
    }
})

//update enigma machine
document.querySelector("#updateSettings").addEventListener("click",()=>{
    let rotorSelections = document.querySelectorAll(".rotorOption")
    let rotorPositions = document.querySelectorAll(".rotorPositonOption")
    let reflector = document.querySelector("#reflectorOption")
    console.log(rotorPositions)
    enigma=new Enigma([
        new Rotor(rotorSelections[0].value,rotorPositions[0].value),
        new Rotor(rotorSelections[1].value,rotorPositions[1].value),
        new Rotor(rotorSelections[2].value,rotorPositions[2].value)
    ],new Reflector(reflector.value))
    inHistory.innerHTML=outHistory.innerHTML=""
})
function handleInput(letter) {
    key = keys[quertz.indexOf(letter)]
    key.classList.add("pressed")
    setTimeout(_ => key.classList.remove("pressed"), (200));
    out = enigma.input(letter)
    //showPath(out.path)
    lightLamp(out.out)
    inHistory.innerHTML += letter
    outHistory.innerHTML += out.out
    enigma.increment()
    console.log("w")
}
function lightLamp(letter) {
    let el = lamps[quertz.indexOf(letter)]
    el.classList.add("on")
    setTimeout(_ => el.classList.remove("on"), (500));
}