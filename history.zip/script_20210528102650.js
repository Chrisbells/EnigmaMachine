// resources
// https://www.cryptomuseum.com/crypto/enigma/wiring.htm#9
// https://www.cs.cornell.edu/courses/cs3110/2018sp/a1/a1.html

let quertzy = "QWERTZUIOASDFGHJKPYXCVBNML".split("")
let alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("")

letterIndex = (letter) => letter.charCodeAt(0) - 65
class Rotor {
    constructor(letterMap, turnover) {
        this.map = letterMap.split("")
        this.turnover = letterIndex(turnover)
    }
    setPosition(pos) {
        this.pos = pos;
    }
    increment(){
        this.pos++
        this.pos%=26
    }
    inputFromRight(letter) {
        return this.map[(letterIndex(letter) + this.pos) % 26]
    }
    inputFromLeft(letter) {
        return alphabet[(this.map.indexOf(letter)+this.pos) % 26]
    }
}
class Reflector {
    constructor(letterMap) {
        this.map = letterMap.split("")
    }
    input(letter) {
        return this.map[letterIndex(letter)]
    }
}
class Enigma {
    constructor(leftRotor = wheel3, leftRotorPos, middleRotor = wheel2, middleRotorPos, rightRotor = wheel1, rightRotorPos, reflector = reflectorB) {
        this.rotors = [rightRotor, middleRotor, leftRotor]
        leftRotor.setPosition(leftRotorPos)
        middleRotor.setPosition(middleRotorPos)
        rightRotor.setPosition(rightRotorPos)
        this.reflector = reflector
    }
    input(letter) {
        let temp = letter
        console.log(temp)
        //going right to left through rotors
        for (let rotor = 0; rotor < this.rotors.length; rotor++) {
            temp = this.rotors[i].inputFromRight(temp)
            console.log(temp)
        }
        //reflector
        temp = this.reflector.input(temp)
        console.log(temp)
        //going left to right through rotors
        for (let rotor = this.wheels.length - 1; rotor >= 0; rotor--) {
            temp = this.rotors[rotor].inputFromLeft(temp)
            console.log(temp)
        }
        return temp
    }
    increment(){
        for (wheel=0;wheel<this.wheels.length;wheel++) {
            cw=wheels[wheel]
            if (wheel<2 && cw.turnover==cw.pos){
                this.wheels[wheel-1].increment()
            }
            cw.increment()
        }
    }
}
//wiring for enigma 1
let wheel1 = new Rotor("EKMFLGDQVZNTOWYHXUSPAIBRCJ", "Q")
let wheel2 = new Rotor("AJDKSIRUXBLHWTMCQGZNPYFVOE", "E")
let wheel3 = new Rotor("BDFHJLCPRTXVZNYEIWGAKMUSQO", "V")
let wheel4 = new Rotor("ESOVPZJAYQUIRHXLNFTGKDCMWB", "J")
let wheel5 = new Rotor("VZBRGITYUPSDNHLXAWMJQOFECK", "Z")
let reflectorA = new Reflector("EJMZALYXVBWFCRQUONTSPIKHGD")
let reflectorB = new Reflector("YRUHQSLDPXNGOKMIEBFZCWVJAT")
let reflectorC = new Reflector("FVPJIAOYEDRZXWGCTKUQSBNMHL")

document.querySelectorAll(".key").forEach(element => {
    element.addEventListener("click",()=>{
        handleClick(element.innerHTML)
    })
});

function lightLamp(letter){
    let el = document.querySelectorAll(".lamp")[quertzy.indexOf(letter)]
    el.classList.add("on")
    setTimeout(() => {
        el.classList.remove("on")
    }, (500));
}

enigma=new Enigma(wheel1,wheel2)