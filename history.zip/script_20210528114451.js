// resources
// https://www.cryptomuseum.com/crypto/enigma/wiring.htm#9
// https://www.cs.cornell.edu/courses/cs3110/2018sp/a1/a1.html

let quertzy = "QWERTZUIOASDFGHJKPYXCVBNML".split("")
let alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("")

letterIndex = (letter) => letter.charCodeAt(0) - 65
class Rotor {
    constructor(letterMap, turnover) {
        this.map = letterMap.split("")
        this.turnover = letterIndex(turnover)
    }
    setPosition(position) {
        this.position = position;
    }
    increment(){
        this.position++
        this.position%=26
    }
    atTurnover(){
        return this.position==this.position
    }
    inputFromRight(letter) {
        return this.map[(letterIndex(letter) + this.position) % 26]
    }
    inputFromLeft(letter) {
        return alphabet[(this.map.indexOf(letter)+this.position) % 26]
    }
}
class Reflector {
    constructor(letterMap) {
        this.map = letterMap.split("")
    }
    input(letter) {
        return this.map[letterIndex(letter)]
    }
}
class Enigma {
    constructor(leftRotor = rotor3, leftRotorPos, middleRotor = rotor2, middleRotorPos, rightRotor = rotor1, rightRotorPos, reflector = reflectorB) {
        this.rotors = [rightRotor, middleRotor, leftRotor]
        leftRotor.setPosition(leftRotorPos)
        middleRotor.setPosition(middleRotorPos)
        rightRotor.setPosition(rightRotorPos)
        this.reflector = reflector
    }
    input(letter) {
        let temp = letter
        console.log(temp)
        //going right to left through rotors
        for (let rotor = 0; rotor < this.rotors.length; rotor++) {
            temp = this.rotors[i].inputFromRight(temp)
            console.log(temp)
        }
        //reflector
        temp = this.reflector.input(temp)
        console.log(temp)
        //going left to right through rotors
        for (let rotor = this.rotors.length - 1; rotor >= 0; rotor--) {
            temp = this.rotors[rotor].inputFromLeft(temp)
            console.log(temp)
        }
        return temp
    }
    increment(){
        // when rotor is at its turnover position then and moves the next rotor
        //for the middle rotor to move the right rotor has to be at its turnover position
        // for the left rotor to move the middle and right rotor have to be at their turnover position
        let midRotorIncremented=true

        if(this.rotors[0].atTurnover()) {
            this.rotors[1].increment()
            midRotorIncremented=true
        }
        if(this.rotors[1].atTurnover() && midRotorIncremented) {
            this.rotors[2].increment()
        }
        // incrementing both after checking both 
        // if the middle rotor moves and then it is checked
        if (moveMiddleRotor) 
        if (moveLeftRotor) this.rotors[2].increment()
        this.rotors[0].increment()
    }
}
//wiring for enigma 1
let rotor1 = new Rotor("EKMFLGDQVZNTOWYHXUSPAIBRCJ", "Q")
let rotor2 = new Rotor("AJDKSIRUXBLHWTMCQGZNPYFVOE", "E")
let rotor3 = new Rotor("BDFHJLCPRTXVZNYEIWGAKMUSQO", "V")
let rotor4 = new Rotor("ESOVPZJAYQUIRHXLNFTGKDCMWB", "J")
let rotor5 = new Rotor("VZBRGITYUPSDNHLXAWMJQOFECK", "Z")
let reflectorA = new Reflector("EJMZALYXVBWFCRQUONTSPIKHGD")
let reflectorB = new Reflector("YRUHQSLDPXNGOKMIEBFZCWVJAT")
let reflectorC = new Reflector("FVPJIAOYEDRZXWGCTKUQSBNMHL")

document.querySelectorAll(".key").forEach(element => {
    element.addEventListener("click",()=>{
        handleClick(element.innerHTML)
    })
});

function lightLamp(letter){
    let el = document.querySelectorAll(".lamp")[quertzy.indexOf(letter)]
    el.classList.add("on")
    setTimeout(() => {
        el.classList.remove("on")
    }, (500));
}

enigma=new Enigma(rotor1,rotor2)