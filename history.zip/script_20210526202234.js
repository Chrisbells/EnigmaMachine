// resources
// https://www.cryptomuseum.com/crypto/enigma/wiring.htm#9
// https://www.cs.cornell.edu/courses/cs3110/2018sp/a1/a1.html

let quertzy = "QWERTZUIOASDFGHJKPYXCVBNML".split("")
let alphabet = "abcdefghijklmnopqrstuvwxyz".split("")

letterIndex = (letter) => letter.charCodeAt(0) - 97
class Rotor {
    constructor(letterMap, notch, turnover) {
        this.map = letterMap.split("")
        this.notch = letterIndex(notch)
        this.turnover = letterIndex(turnover)
    }
    setPosition(pos) {
        this.pos = pos
    }
    inputFromRight(letter) {
        return this.map[(letterIndex(letter) + this.pos) % 26]
    }
    inputFromLeft(letter) {
        return alphabet[(this.map.indexOf(letter)+this.pos) % 26]
    }
}
class Reflector {
    constructor(letterMap) {
        this.map = letterMap.split("")
    }
    input(letter) {
        return this.map[letterIndex(letter)]
    }
}
class Enigma {
    constructor(leftWheel = wheel3, leftWheelPos, middleWheel = wheel2, middleWheelPos, rightWheel = wheel1, rightWheelPos, reflector = reflectorB) {
        this.wheels = [rightWheel, middleWheel, leftWheel]
        leftWheel.setPosition(leftWheelPos)
        middleWheel.setPosition(middleWheelPos)
        rightWheel.setPosition(rightWheelPos)
        this.reflector = reflector
    }
    input(letter) {
        let temp = letter
        //going right to left through rotors
        for (i = 0; i < this.wheels.length; i++) {
            temp = this.wheels[i].inputFromRight(temp)
        }
        //reflector
        temp = this.reflector.input(temp)
        //going left to right through rotors
        for (i = this.wheels.length - 1; i >= 0; i--) {
            temp = this.wheels[i].inputFromLeft(temp)
        }
        return temp
    }
    increment(){
        for (wheel=0;wheel<this.wheels.length;wheel++) {
            this.wheels++
            if (wheel<2){
                if (this.wheels[wheel].pos>this.wheels[wheel].turnover){
                    // check this later
                    this.wheels[wheel]=0
                    this.wheels[wheel+1].pos++
                }
            }
        }
    }
}
//wiring for enigma 1
let wheel1 = new Rotor("ekmflgdqvzntowyhxuspaibrcj", 'y', 'q')
let wheel2 = new Rotor("ajdksiruxblhwtmcqgznpyfvoe", "m", "e")
let wheel3 = new Rotor("bdfhjlcprtxvznyeiwgakmusqo", "d", "v")
let wheel4 = new Rotor("esovpzjayquirhxlnftgkdcmwb", "r", "j")
let wheel5 = new Rotor("vzbrgityupsdnhlxawmjqofeck", "h", "z")
let reflectorA = new Reflector("ejmzalyxvbwfcrquontspikhgd")
let reflectorB = new Reflector("yruhqsldpxngokmiebfzcwvjat")
let reflectorC = new Reflector("fvpjiaoyedrzxwgctkuqsbnmhl")

document.querySelectorAll(".key").forEach(element => {
    element.addEventListener("click",()=>{
        handleClick(element.innerHTML)
    })
});

function handleClick(letter){
    document.querySelector('.lamp')[quertzy.indexOf(letter)].classList.add("on")
}
